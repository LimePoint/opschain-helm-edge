{{/*
Expand the name of the chart.
*/}}
{{- define "opschain.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "opschain.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "opschain.labels" -}}
helm.sh/chart: {{ include "opschain.chart" . }}
{{ include "opschain.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "opschain.selectorLabels" -}}
app.kubernetes.io/name: {{ include "opschain.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: OpsChain
{{- end }}

{{- define "opschain.caIssuerName" -}}
opschain-ca-issuer
{{- end }}

{{- define "opschain.caSecretName" -}}
opschain-ca-key-pair
{{- end }}

{{- define "opschain.buildServiceHostName" -}}
opschain-build-service
{{- end }}

{{- define "opschain.secretVaultHostName" -}}
opschain-secret-vault-0.opschain-secret-vault-internal
{{- end }}

{{- define "opschain.secretVaultExternalHostName" -}}
{{- .Values.global.secretVaultExternalHostName -}}
{{- end }}

{{/*
Kong's proxy TLS Service port - the port the ingress publishes on the cluster network, and so the
port every in-cluster client and every node's container runtime dials. A parent chart can read a
value the operator supplied for a subchart but not the subchart's own defaults, hence the literal
443 fallback, which is Kong's default when `kong.proxy.tls.servicePort` is left unset.
*/}}
{{- define "opschain.kongProxyTlsServicePort" -}}
{{- dig "proxy" "tls" "servicePort" 443 (.Values.kong | default dict) -}}
{{- end }}

{{/*
The port an *external* client dials to reach the secret vault at global.secretVaultExternalHostName.
This builds BAO_API_ADDR, which is the address a standby vault pod 307-redirects clients to - the
postgresql storage backend does no request forwarding - so it has to be the port that reaches Kong
from outside the cluster. That is not always the port Kong's Service publishes: a load balancer in
front may translate it (e.g. it listens on 443 and forwards to the node on 17001, in which case this
is 443 while OPSCHAIN_INGRESS_TLS_PORT stays 17001). Left unset it follows Kong's own Service port,
which is right whenever nothing translates it, so the two cannot silently drift.
`global.ingressTlsPort` is the deprecated spelling - it still wins if set, and NOTES.txt warns.
*/}}
{{- define "opschain.secretVaultExternalPort" -}}
{{- .Values.global.secretVaultExternalPort | default .Values.global.ingressTlsPort | default (include "opschain.kongProxyTlsServicePort" .) -}}
{{- end }}

{{- define "opschain.secretVaultExternalCertificateSecretName" -}}
{{- .Values.secretVault.externalCertificateSecretName | default "opschain-secret-vault-external-cert" -}}
{{- end }}

{{- define "opschain.buildServicePortNumber" -}}
50000
{{- end }}

{{- define "opschain.imagePullSecretName" -}}
opschain-image-secret
{{- end }}

{{- define "opschain.apiWorkerImage" -}}
{{- .Values.apiWorker.image | default .Values.api.image | default (printf "limepoint/opschain-api:%s" .Values.env.OPSCHAIN_VERSION) }}
{{- end }}

{{- define "opschain.mintModelStepsApiImage" -}}
{{- .Values.mintModelStepsApi.image | default (printf "limepoint/opschain-mintmodel-steps-api:%s" .Values.env.OPSCHAIN_VERSION) }}
{{- end }}

{{/*
The internal registry as clients on the cluster network - including every node's container runtime -
reach it, i.e. through Kong's proxy TLS Service port (OPSCHAIN_INGRESS_TLS_PORT). Runner, agent and
MintModel API pods are all started with images under this address. This is the Service port, not the
port an outside client dials - for that see `opschain.secretVaultExternalPort`.
*/}}
{{- define "opschain.internalRegistryHost" -}}
{{- printf "%s:%s" (.Values.env.OPSCHAIN_IMAGE_REGISTRY_HOST | toString) (.Values.env.OPSCHAIN_INGRESS_TLS_PORT | toString) -}}
{{- end }}

{{- define "opschain.runnerImageName" -}}
{{- .Values.env.OPSCHAIN_RUNNER_IMAGE | default (printf "limepoint/opschain-%s:%s" (.Values.env.OPSCHAIN_RUNNER_NAME | default "runner-enterprise") (.Values.env.OPSCHAIN_VERSION | toString)) -}}
{{- end }}

{{/*
The base runner image in the internal registry, as `opschain:copy_runner_image` stores it. Step and
agent pods run images built from this one, so a node holding its layers pulls only the built image's
own layers.
*/}}
{{- define "opschain.runnerImage" -}}
{{- printf "%s/%s" (include "opschain.internalRegistryHost" .) (include "opschain.runnerImageName" .) -}}
{{- end }}

{{/*
The MintModel API image, exactly as the API asks kubelet for it when it starts an on demand
`opschain-mm-*` pod: the internal registry's external address, and the `-unstable` suffix iff the
runner image (which the API derives it from) carries one. Must stay byte identical to
`ImageNameBuilding#mintmodel_api_image_name` in the API, or a pre-pull warms the wrong reference.
*/}}
{{- define "opschain.mintModelApiImage" -}}
{{- $suffix := ternary "-unstable" "" (hasSuffix "-unstable" (regexReplaceAll ":[^:/]*$" (include "opschain.runnerImageName" .) "")) -}}
{{- printf "%s/limepoint/opschain-mintmodel-api%s:%s" (include "opschain.internalRegistryHost" .) $suffix (.Values.env.OPSCHAIN_VERSION | toString) -}}
{{- end }}

{{- define "opschain.initImage" -}}
{{- default (printf "limepoint/opschain-init:%s" .Values.env.OPSCHAIN_VERSION) }}
{{- end }}

{{- define "opschain.debugToolboxImage" -}}
{{- .Values.debugToolbox.image | default (printf "limepoint/opschain-debug-toolbox:%s" .Values.env.OPSCHAIN_VERSION) }}
{{- end }}

{{- define "opschain.debugToolbox.sidecarSpec" -}}
- image: {{ include "opschain.debugToolboxImage" . }}
  imagePullPolicy: {{ if eq .Values.env.OPSCHAIN_VERSION "edge" }}Always{{ else }}IfNotPresent{{ end }}
  name: debug-toolbox
  command: ["sleep", "infinity"]
  resources:
    limits:
      memory: 256Mi
      cpu: 200m
    requests:
      memory: 64Mi
      cpu: 50m
  securityContext:
    allowPrivilegeEscalation: false
{{- end }}

{{/*
Resolve the opschain-db image to be used.
*/}}
{{- define "opschain.dbImage" -}}
{{- if .Values.db.cnpg.imageName -}}
{{- .Values.db.cnpg.imageName -}}
{{- else if .Values.env.POSTGRESQL_VERSION -}}
{{- printf "limepoint/opschain-db:%s" .Values.env.POSTGRESQL_VERSION -}}
{{- else -}}
{{- printf "limepoint/opschain-db:17.5" -}}
{{- end -}}
{{- end -}}

{{/*
Resolve the PgBouncer image used by the CNPG Pooler.
*/}}
{{- define "opschain.pgBouncerImage" -}}
{{- .Values.db.cnpg.pooler.image | default "limepoint/opschain-pgbouncer:1.24.1" -}}
{{- end -}}

{{/*
Alternative DNS names for the CNPG cluster's generated server certificate.
*/}}
{{- define "opschain.db.serverAltDNSNames" -}}
{{- $cluster := .Values.db.cnpg.clusterName -}}
{{- $names := list (printf "%s-pooler-rw" $cluster) (printf "%s-rw-headless" $cluster) -}}
{{- $names = concat $names (.Values.db.cnpg.security.tls.serverAltDNSNames | default list) -}}
{{- toYaml (uniq $names) -}}
{{- end -}}

{{/*
Host of the local primary Postgres service.

Backups and recovery must reach Postgres directly, never through the PgBouncer pooler due to authentication issues.
*/}}
{{- define "opschain.db.primaryHost" -}}
{{- .Values.db.forcePgHost | default (printf "%s-rw" .Values.db.cnpg.clusterName) -}}
{{- end -}}

{{/*
Host for connections that must never be pooled.

Data-path separation: a handful of connections are long-lived, singular and hold session state, and
they break badly when a pooler pod is replaced - e.g Que's locker, the dedicated
LISTEN/NOTIFY connections, and openbao's HA storage connections.
Everything else stays on opschain.pgHost, recovers on its own, and is exactly what a pooler is for.

On a replica cluster both paths resolve to the remote primary from externalClusters,
so the two only diverge on a primary cluster with db.cnpg.pooler.enabled.
*/}}
{{- define "opschain.db.directHost" -}}
{{- if .Values.db.forcePgHost -}}
  {{- .Values.db.forcePgHost -}}
{{- else -}}
{{- $replica := .Values.db.cnpg.replica | default dict -}}
{{- if $replica.enabled -}}
  {{- $primary := $replica.primary -}}
  {{- range $cluster := .Values.db.cnpg.externalClusters -}}
    {{- if eq $cluster.name $primary -}}{{ $cluster.connectionParameters.host }}{{- end -}}
  {{- end -}}
{{- else if .Values.db.cnpg.primaryHeadlessService.enabled -}}
  {{- printf "%s-rw-headless" .Values.db.cnpg.clusterName -}}
{{- else -}}
  {{- printf "%s-rw" .Values.db.cnpg.clusterName -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "opschain.db.directPort" -}}
{{- include "opschain.pgPort" . -}}
{{- end -}}

{{- define "opschain.pgHost" -}}
{{- if .Values.db.forcePgHost -}}
  {{- .Values.db.forcePgHost -}}
{{- else -}}
{{- $replica := .Values.db.cnpg.replica | default dict -}}
{{- if $replica.enabled -}}
  {{- $primary := $replica.primary -}}
  {{- range $cluster := .Values.db.cnpg.externalClusters -}}
    {{- if eq $cluster.name $primary -}}{{ $cluster.connectionParameters.host }}{{- end -}}
  {{- end -}}
{{- else if .Values.db.cnpg.primaryHeadlessService.enabled -}}
  {{- printf "%s-rw-headless" .Values.db.cnpg.clusterName -}}
{{- else if .Values.db.cnpg.pooler.enabled -}}
  {{- printf "%s-pooler-rw" .Values.db.cnpg.clusterName -}}
{{- else -}}
  {{- printf "%s-rw" .Values.db.cnpg.clusterName -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "opschain.pgPort" -}}
{{- if .Values.db.forcePgPort -}}
  {{- .Values.db.forcePgPort -}}
{{- else -}}
{{- $replica := .Values.db.cnpg.replica | default dict -}}
{{- if $replica.enabled -}}
  {{- $primary := $replica.primary -}}
  {{- range $cluster := .Values.db.cnpg.externalClusters -}}
    {{- if eq $cluster.name $primary -}}{{ $cluster.connectionParameters.port | default "5432" }}{{- end -}}
  {{- end -}}
{{- else -}}
  5432
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "opschain.secretVaultClusterPort" -}}
8201
{{- end -}}

{{- define "opschain.baoPgConnectionUrl" -}}
postgresql://opschain@{{ include "opschain.db.directHost" . }}:{{ include "opschain.db.directPort" . }}/opschain?sslmode=require
{{- end -}}

{{- define "opschain.openbaoConfig" -}}
ui = true

listener "tcp" {
  address = "[::]:8200"
  cluster_address = "[::]:{{ include "opschain.secretVaultClusterPort" . }}"
  tls_cert_file = "/secret-vault-certs/tls-combined.pem"
  tls_key_file = "/secret-vault-certs/tls.key"
  tls_client_ca_file = "/secret-vault-certs/ca.crt"
}

storage "postgresql" {
  ha_enabled = "true"
}

# Lets OpenBao label its own pod openbao-active: "true"/"false" based on leader status - required
# for the server.service.active/standby Services (values.yaml) to have any endpoints. Needs the
# server.serviceAccount.serviceDiscovery RBAC (values.yaml) to actually patch the pod label.
service_registration "kubernetes" {}

seal "static" {
  current_key_id = "opschain-secret-vault-seal-key"
  current_key    = "file:///openbao/secrets"
}
{{- end -}}

{{/*
The cluster's identity, as every OpsChain component needs it. The role is derived from the
distributed topology rather than configured separately, so it cannot drift from what the
cluster actually is.
*/}}
{{- define "opschain.clusterRole" -}}
{{- if .Values.db.cnpg.replica.enabled -}}replica{{- else -}}primary{{- end -}}
{{- end -}}

{{- define "opschain.clusterEnv" -}}
- name: OPSCHAIN_CLUSTER_NAME
  value: {{ .Values.db.cnpg.clusterName | quote }}
- name: OPSCHAIN_CLUSTER_ROLE
  value: {{ include "opschain.clusterRole" . | quote }}
{{- end -}}

{{- define "opschain.systemPriorityClassName" -}}
{{ .Values.priorityClasses.system.name | default "opschain-system" }}
{{- end }}

{{- define "opschain.runnerPriorityClassName" -}}
{{ .Values.priorityClasses.runner.name | default "opschain-runner" }}
{{- end }}
