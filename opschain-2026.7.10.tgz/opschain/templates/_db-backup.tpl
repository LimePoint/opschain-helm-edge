{{/*
Returns "true" when the database cluster is currently hibernated, otherwise "".
Checks the live cnpg.io/hibernation annotation via lookup, so it detects hibernation
set either declaratively (stopDatabase) or a direct kubectl annotate.
*/}}
{{- define "opschain.db.hibernated" -}}
{{- $cluster := lookup "postgresql.cnpg.io/v1" "Cluster" .Release.Namespace .Values.db.cnpg.clusterName -}}
{{- if $cluster -}}
{{- if eq (index ($cluster.metadata.annotations | default dict) "cnpg.io/hibernation") "on" -}}
true
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Name of the database replication client-certificate secret (used by pg_basebackup).
*/}}
{{- define "opschain.db.replicationSecretName" -}}
{{- if .Values.db.cnpg.security.tls.customCerts.enabled -}}
{{- .Values.db.cnpg.security.tls.customCerts.replicationTLSSecret -}}
{{- else -}}
{{- printf "%s-replication" .Values.db.cnpg.clusterName -}}
{{- end -}}
{{- end -}}

{{/*
Name of the database server CA secret (used to verify the server TLS certificate).
*/}}
{{- define "opschain.db.caSecretName" -}}
{{- if .Values.db.cnpg.security.tls.customCerts.enabled -}}
{{- .Values.db.cnpg.security.tls.customCerts.serverCASecret -}}
{{- else -}}
{{- printf "%s-ca" .Values.db.cnpg.clusterName -}}
{{- end -}}
{{- end -}}

{{/*
Path within the PVC to store the backups.
*/}}
{{- define "opschain.db.backupMountPath" -}}
{{- "/opt/backup" -}}
{{- end -}}

{{/*
Shared pod spec for the database backup CronJob and pre-deploy hook Job.
Call with a dict: (dict "ctx" . "method" "physical|logical" "subdir" "periodic|pre-deploy")
*/}}
{{- define "opschain.dbBackup.podSpec" -}}
{{- $ctx := .ctx -}}
{{- $method := .method -}}
{{- $subdir := .subdir -}}
{{- $backup := $ctx.Values.db.backup -}}
{{- $image := $backup.image | default (include "opschain.dbImage" $ctx) -}}
{{- $repl := include "opschain.db.replicationSecretName" $ctx -}}
{{- $ca := include "opschain.db.caSecretName" $ctx -}}
restartPolicy: Never
serviceAccountName: opschain-api
securityContext:
  runAsUser: 26
  runAsGroup: 26
  fsGroup: 26
  fsGroupChangePolicy: OnRootMismatch
imagePullSecrets:
  - name: {{ include "opschain.imagePullSecretName" $ctx }}
containers:
  - name: backup
    image: {{ $image }}
    imagePullPolicy: {{ $backup.imagePullPolicy }}
    command:
      - /bin/bash
      - -c
      - 'if [ ! -x /usr/local/bin/opschain-db-backup ]; then echo "ERROR: /usr/local/bin/opschain-db-backup is not present in this opschain-db image. This image predates the automated backup feature - refresh the opschain-db image on your nodes (see the release notes) and retry." >&2; exit 1; fi; exec /usr/local/bin/opschain-db-backup "$@"'
      - opschain-db-backup
    args:
      - "--method"
      - {{ $method | quote }}
      - "--out"
      - {{ printf "%s/%s" (include "opschain.db.backupMountPath" $ctx) $subdir | quote }}
      - "--retention-count"
      - {{ $backup.retention.count | quote }}
      - "--retention-days"
      - {{ $backup.retention.days | quote }}
      - "--max-rate"
      - {{ $backup.maxRate | quote }}
    env:
      - name: PGHOST
        value: {{ include "opschain.pgHost" $ctx | quote }}
      - name: PGPORT
        value: {{ include "opschain.pgPort" $ctx | quote }}
      - name: PGDATABASE
        value: {{ $ctx.Values.db.cnpg.database.name | quote }}
      - name: PGUSER
        value: {{ $ctx.Values.db.cnpg.database.owner | quote }}
      - name: PGSSLMODE
        value: "require"
      - name: PGSSLROOTCERT
        value: "/db-certs/ca/ca.crt"
      - name: PGPASSWORD
        valueFrom:
          secretKeyRef:
            name: {{ $ctx.Values.db.cnpg.database.secretName }}
            key: password
      {{- if $ctx.Values.env.TZ }}
      - name: TZ
        value: {{ $ctx.Values.env.TZ | quote }}
      {{- end }}
      {{- range $key, $value := $ctx.Values.db.cnpg.env }}
      - name: {{ $key }}
        value: {{ $value | quote }}
      {{- end }}
    volumeMounts:
      - name: backup
        mountPath: {{ include "opschain.db.backupMountPath" $ctx }}
      - name: db-replication-cert
        mountPath: /db-certs/replication
        readOnly: true
      - name: db-ca-cert
        mountPath: /db-certs/ca
        readOnly: true
    resources:
      {{- toYaml $backup.resources | nindent 6 }}
    securityContext:
      allowPrivilegeEscalation: false
volumes:
  - name: backup
    persistentVolumeClaim:
      claimName: opschain-db-backup
  - name: db-replication-cert
    secret:
      secretName: {{ $repl }}
      defaultMode: 0640
  - name: db-ca-cert
    secret:
      secretName: {{ $ca }}
      defaultMode: 0640
{{- end -}}
