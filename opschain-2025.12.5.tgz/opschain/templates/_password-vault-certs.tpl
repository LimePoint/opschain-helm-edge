{{/*
OpenBao certificates volume mount
*/}}
{{- define "opschain.secretVault.volumeMount" -}}
{{- if .Values.openbao.global.enabled }}
- name: opschain-secret-vault-cert
  readOnly: true
  mountPath: /secret-vault-certs
{{- end }}
{{- end -}}

{{/*
OpenBao certificates volume
*/}}
{{- define "opschain.secretVault.volume" -}}
{{- if .Values.openbao.global.enabled }}
- name: opschain-secret-vault-cert
  secret:
    secretName: opschain-secret-vault-cert
{{- end }}
{{- end -}}
