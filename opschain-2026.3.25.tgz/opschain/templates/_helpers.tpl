{{/*
Expand the name of the chart.
*/}}
{{- define "opschain.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "opschain.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "opschain.labels" -}}
helm.sh/chart: {{ include "opschain.chart" . }}
{{ include "opschain.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "opschain.selectorLabels" -}}
app.kubernetes.io/name: {{ include "opschain.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: OpsChain
{{- end }}

{{- define "opschain.caIssuerName" -}}
opschain-ca-issuer
{{- end }}

{{- define "opschain.caSecretName" -}}
opschain-ca-key-pair
{{- end }}

{{- define "opschain.buildServiceHostName" -}}
opschain-build-service
{{- end }}

{{- define "opschain.secretVaultHostName" -}}
opschain-secret-vault-0.opschain-secret-vault-internal
{{- end }}

{{- define "opschain.secretVaultExternalHostName" -}}
{{- .Values.global.secretVaultExternalHostName -}}
{{- end }}

{{- define "opschain.secretVaultExternalCertificateSecretName" -}}
{{- .Values.secretVault.externalCertificateSecretName | default "opschain-secret-vault-external-cert" -}}
{{- end }}

{{- define "opschain.buildServicePortNumber" -}}
50000
{{- end }}

{{- define "opschain.imagePullSecretName" -}}
opschain-image-secret
{{- end }}

{{- define "opschain.apiWorkerImage" -}}
{{- .Values.apiWorker.image | default .Values.api.image | default (printf "limepoint/opschain-api:%s" .Values.env.OPSCHAIN_VERSION) }}
{{- end }}

{{- define "opschain.mintModelApiImage" -}}
{{- .Values.mintModelApi.image | default (printf "limepoint/opschain-mintmodel-api:%s" .Values.env.OPSCHAIN_VERSION) }}
{{- end }}

{{- define "opschain.mintModelStepsApiImage" -}}
{{- .Values.mintModelStepsApi.image | default (printf "limepoint/opschain-mintmodel-steps-api:%s" .Values.env.OPSCHAIN_VERSION) }}
{{- end }}

{{- define "opschain.initImage" -}}
{{- default (printf "limepoint/opschain-init:%s" .Values.env.OPSCHAIN_VERSION) }}
{{- end }}

{{- define "opschain.pgHost" -}}
{{- if .Values.db.forcePgHost -}}
  {{- .Values.db.forcePgHost -}}
{{- else -}}
{{- $replica := .Values.db.cnpg.replica | default dict -}}
{{- if $replica.enabled -}}
  {{- $primary := $replica.primary -}}
  {{- range $cluster := .Values.db.cnpg.externalClusters -}}
    {{- if eq $cluster.name $primary -}}{{ $cluster.connectionParameters.host }}{{- end -}}
  {{- end -}}
{{- else -}}
  {{- printf "%s-rw" .Values.db.cnpg.clusterName -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "opschain.pgPort" -}}
{{- if .Values.db.forcePgPort -}}
  {{- .Values.db.forcePgPort -}}
{{- else -}}
{{- $replica := .Values.db.cnpg.replica | default dict -}}
{{- if $replica.enabled -}}
  {{- $primary := $replica.primary -}}
  {{- range $cluster := .Values.db.cnpg.externalClusters -}}
    {{- if eq $cluster.name $primary -}}{{ $cluster.connectionParameters.port | default "5432" }}{{- end -}}
  {{- end -}}
{{- else -}}
  5432
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "opschain.secretVaultClusterPort" -}}
8201
{{- end -}}
{{- end -}}

{{- define "opschain.baoPgConnectionUrl" -}}
postgresql://opschain@{{ include "opschain.pgHost" . }}:{{ include "opschain.pgPort" . }}/opschain?sslmode=require
{{- end -}}

{{- define "opschain.openbaoConfig" -}}
ui = true

listener "tcp" {
  address = "[::]:8200"
  cluster_address = "[::]:{{ include "opschain.secretVaultClusterPort" . }}"
  tls_cert_file = "/secret-vault-certs/tls-combined.pem"
  tls_key_file = "/secret-vault-certs/tls.key"
  tls_client_ca_file = "/secret-vault-certs/ca.crt"
}

storage "postgresql" {
  ha_enabled = "true"
}

seal "static" {
  current_key_id = "opschain-secret-vault-seal-key"
  current_key    = "file:///openbao/secrets"
}
{{- end -}}
