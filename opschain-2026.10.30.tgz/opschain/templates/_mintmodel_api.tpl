{{- define "opschain.mintModelApi.validate" -}}
{{- if not (has .Values.mintModelApi.isolation (list "never" "request")) -}}
{{- fail (printf "mintModelApi.isolation must be \"never\" or \"request\", got %q" (.Values.mintModelApi.isolation | toString)) -}}
{{- end -}}
{{- if lt (int .Values.mintModelApi.concurrency) 1 -}}
{{- fail (printf "mintModelApi.concurrency must be at least 1, got %v" .Values.mintModelApi.concurrency) -}}
{{- end -}}
{{- if and (not .Values.stopped) (lt (int .Values.mintModelApi.replicas) 1) -}}
{{- fail (printf "mintModelApi.replicas must be at least 1, got %v: with no replicas OpsChain has no capacity to render MintModels, and renders wait forever. Set stopped: true to stop OpsChain instead" .Values.mintModelApi.replicas) -}}
{{- end -}}
{{- if or (lt (int .Values.mintModelApi.transformer.spares) 0) (gt (int .Values.mintModelApi.transformer.spares) (int .Values.mintModelApi.concurrency)) -}}
{{- fail (printf "mintModelApi.transformer.spares must be between 0 and mintModelApi.concurrency (%v), got %v" .Values.mintModelApi.concurrency .Values.mintModelApi.transformer.spares) -}}
{{- end -}}
{{- if not (regexMatch "^[1-9][0-9]*[kKmMgG]$" (.Values.mintModelApi.transformer.heap | toString)) -}}
{{- fail (printf "mintModelApi.transformer.heap must be a JVM size such as 1536m or 2g, got %q" (.Values.mintModelApi.transformer.heap | toString)) -}}
{{- end -}}
{{- with dig "limits" "memory" "" (.Values.mintModelApi.resources | default dict) -}}
{{- $limit := include "opschain.mintModelApi.quantityMi" (dict "value" . "name" "mintModelApi.resources.limits.memory") | int -}}
{{- $needed := include "opschain.mintModelApi.neededMemoryMi" $ | int -}}
{{- if lt $limit $needed -}}
{{- fail (printf "mintModelApi.resources.limits.memory (%s) is too small for mintModelApi.concurrency %v and mintModelApi.transformer.heap %s: it needs at least %dMi (100Mi for the server, 320Mi per concurrent render and %v transformer JVMs of heap + 320Mi each). Raise the limit, or lower the heap or concurrency" (toString .) $.Values.mintModelApi.concurrency $.Values.mintModelApi.transformer.heap $needed (add1 (int $.Values.mintModelApi.concurrency))) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "opschain.mintModelApi.neededMemoryMi" -}}
{{- $concurrency := int .Values.mintModelApi.concurrency -}}
{{- $heap := include "opschain.mintModelApi.heapMi" .Values.mintModelApi.transformer.heap | int -}}
{{- add 100 (mul 320 $concurrency) (mul (add1 $concurrency) (add $heap 320)) -}}
{{- end -}}

{{- define "opschain.mintModelApi.heapMi" -}}
{{- $size := . | toString -}}
{{- $factors := dict "k" 0.0009765625 "m" 1.0 "g" 1024.0 -}}
{{- $suffix := regexFind "[kKmMgG]$" $size | lower -}}
{{- mulf (float64 (trimSuffix (regexFind "[kKmMgG]$" $size) $size)) (get $factors $suffix) | ceil | int -}}
{{- end -}}

{{- define "opschain.mintModelApi.quantityMi" -}}
{{- $size := .value | toString -}}
{{- $match := regexFind "^[0-9]+(\\.[0-9]+)?" $size -}}
{{- $factors := dict "" 0.00000095367431640625 "k" 0.0009765625 "M" 0.95367431640625 "G" 953.67431640625 "T" 953674.31640625 "Ki" 0.0009765625 "Mi" 1.0 "Gi" 1024.0 "Ti" 1048576.0 -}}
{{- $suffix := trimPrefix $match $size -}}
{{- if or (not $match) (not (hasKey $factors $suffix)) -}}
{{- fail (printf "%s must be a Kubernetes memory quantity such as 6400Mi or 6.25Gi, got %q (suffixes are case sensitive: m means thousandths of a byte)" .name $size) -}}
{{- end -}}
{{- mulf (float64 $match) (get $factors $suffix) | floor | int -}}
{{- end -}}

{{- define "opschain.mintModelApi.capacity" -}}
{{- ternary 0 (mul (int .Values.mintModelApi.replicas) (int .Values.mintModelApi.concurrency)) .Values.stopped -}}
{{- end -}}

{{- define "opschain.mintModelApi.tokenSecretName" -}}
opschain-mintmodel-api-token
{{- end -}}

{{- define "opschain.mintModelApi.tokenEnv" -}}
- name: OPSCHAIN_MINTMODEL_API_TOKEN
  valueFrom:
    secretKeyRef:
      name: {{ include "opschain.mintModelApi.tokenSecretName" . }}
      key: token
{{- end -}}

{{- define "opschain.mintModelApi.apiEnv" -}}
{{- if .Values.mintModelApi.enabled }}
- name: OPSCHAIN_MINTMODEL_API_URL
  value: http://opschain-mintmodel-api:3000
{{ include "opschain.mintModelApi.tokenEnv" . }}
- name: OPSCHAIN_MINTMODEL_API_CAPACITY
  value: {{ include "opschain.mintModelApi.capacity" . | quote }}
{{- end }}
{{- end -}}

{{- define "opschain.mintModelApi.serverSecurityContext" -}}
{{- if eq .Values.mintModelApi.isolation "request" }}
allowPrivilegeEscalation: true
seccompProfile:
  type: Unconfined
appArmorProfile:
  type: Unconfined
{{- else }}
allowPrivilegeEscalation: false
{{- end }}
{{- end -}}

{{- define "opschain.mintModelApi.scratchVolumeMount" -}}
{{- if eq .Values.mintModelApi.isolation "request" }}
- name: fs-scratch
  mountPath: /var/lib/opschain-fs-scratch
{{- end }}
{{- end -}}

{{- define "opschain.mintModelApi.scratchVolume" -}}
{{- if eq .Values.mintModelApi.isolation "request" }}
- name: fs-scratch
  emptyDir: {}
{{- end }}
{{- end -}}

{{- define "opschain.mintModelApi.isolationEnv" -}}
- name: OPSCHAIN_FORK_FS_ISOLATION
  value: {{ .Values.mintModelApi.isolation | quote }}
{{- if eq .Values.mintModelApi.isolation "request" }}
- name: OPSCHAIN_FORK_FS_SCRATCH_STORAGE
  value: /var/lib/opschain-fs-scratch
{{- end }}
{{- end -}}

{{- define "opschain.mintModelApi.checkImage" -}}
{{- regexReplaceAll "^[^/]*/" (include "opschain.mintModelApiImage" .) "" -}}
{{- end -}}
