{{/*
Build service certificates volume mount
*/}}
{{- define "opschain.buildService.volumeMount" -}}
- name: opschain-build-service-cert
  readOnly: true
  mountPath: /build-service-certs
{{- end -}}

{{/*
Build service certificates volume
*/}}
{{- define "opschain.buildService.volume" -}}
- name: opschain-build-service-cert
  secret:
    secretName: {{ .Values.buildService.certificateSecretName | default "opschain-build-service-cert" }}
{{- end -}}
