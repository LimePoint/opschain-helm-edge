{{- define "opschain.ssh_known_hosts.name" -}}
opschain-ssh-known-hosts
{{- end -}}
{{- define "opschain.sshKnownHosts.volumeMounts" -}}
- name: {{ include "opschain.ssh_known_hosts.name" . | quote }}
  mountPath: /opt/opschain/.ssh/.known_hosts.volume
  subPath: known_hosts
{{- end -}}
{{- define "opschain.sshKnownHosts.volume" -}}
- name: {{ include "opschain.ssh_known_hosts.name" . | quote }}
  configMap:
    name: {{ .Values.sshKnownHostsConfigMapRef | default (include "opschain.ssh_known_hosts.name" . | quote) }}
    items:
      - key: known_hosts
        path: known_hosts
        mode: 0o600
{{- end -}}
