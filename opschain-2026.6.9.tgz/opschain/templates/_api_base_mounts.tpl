{{/*
OpsChain API and worker base volumes
*/}}
{{- define "opschain.api.baseVolumes" -}}
{{ include "opschain.transportableKey.volume" . | trim }}
{{ include "opschain.projectSteps.volume" . | trim }}
{{ include "opschain.secretVault.volume" . | trim }}
{{ include "opschain.buildService.volume" . | trim }}
{{ include "opschain.sshKnownHosts.volume" . | trim }}
{{- end }}

{{/*
OpsChain API and worker base volume mounts
*/}}
{{- define "opschain.api.baseVolumeMounts" -}}
{{ include "opschain.transportableKey.volumeMount" . | trim }}
{{ include "opschain.projectSteps.volumeMount" . | trim }}
{{ include "opschain.secretVault.volumeMount" . | trim }}
{{ include "opschain.buildService.volumeMount" . | trim }}
{{ include "opschain.sshKnownHosts.volumeMounts" . | trim }}
{{- end }}
