{{/*
OpsChain project Git repositories volume mount
*/}}
{{- define "opschain.transportableKey.volumeMount" }}
- name: mintpress-transportable-key
  mountPath: /opt/opschain/.limepoint/localKey
  subPath: localKey
{{- end }}

{{/*
OpsChain project Git repositories volume
*/}}
{{- define "opschain.transportableKey.volume" }}
- name: mintpress-transportable-key
  secret:
    secretName: mintpress-transportable-key
    items:
      - key: localKey
        path: localKey
        mode: 0o444
{{- end }}
