{{/*
OpsChain project Git repositories volume mount
*/}}
{{- define "opschain.projectSteps.volumeMount" }}
- name: opschain-project-git-repos
  mountPath: /opt/opschain/opschain_project_git_repos
- name: step-data
  mountPath: /steps
{{- end }}

{{/*
OpsChain project Git repositories volume
*/}}
{{- define "opschain.projectSteps.volume" }}
- name: opschain-project-git-repos
  persistentVolumeClaim:
    claimName: opschain-project-git-repos-claim
- name: step-data
  persistentVolumeClaim:
    claimName: opschain-step-data-claim
{{- end }}
