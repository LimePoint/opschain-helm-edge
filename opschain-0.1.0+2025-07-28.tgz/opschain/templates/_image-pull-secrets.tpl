{{- define "dockerAuth" }}
{{- printf "%s:%s" .Values.env.OPSCHAIN_DOCKER_USER .Values.env.OPSCHAIN_DOCKER_PASSWORD | b64enc }}
{{- end }}
{{- define "internalRegistryAuth" }}
{{- printf "%s:%s" .Values.trow.trow.user .Values.trow.trow.password | b64enc }}
{{- end }}
{{- define "opschainImagePullSecrets" }}
{
  "auths": {
    "https://index.docker.io/v1/": {
      "auth": "{{ include "dockerAuth" . }}"
    },
    "{{ .Values.env.OPSCHAIN_IMAGE_REGISTRY_HOST }}:{{ .Values.env.OPSCHAIN_IMAGE_REGISTRY_TLS_EXTERNAL_PORT }}": {
      "auth": "{{ include "internalRegistryAuth" . }}"
    },
    "{{ .Values.trow.fullnameOverride }}:8000": {
      "auth": "{{ include "internalRegistryAuth" . }}"
    }
  }
}
{{- end }}
