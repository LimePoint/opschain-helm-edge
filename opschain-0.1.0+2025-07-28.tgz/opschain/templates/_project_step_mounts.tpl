{{/*
Build service certificates volume mount
*/}}
{{- define "opschain.project_steps.volume_mount" -}}
- name: opschain-project-git-repos
  mountPath: /opt/opschain/opschain_project_git_repos
- name: step-data
  mountPath: /steps
{{- end -}}

{{/*
Build service certificates volume
*/}}
{{- define "opschain.project_steps.volume" -}}
- name: opschain-project-git-repos
  persistentVolumeClaim:
    claimName: opschain-project-git-repos-claim
- name: step-data
  persistentVolumeClaim:
    claimName: opschain-step-data-claim
{{- end -}}
