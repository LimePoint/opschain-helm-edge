{{/*
Build service certificates volume mount
*/}}
{{- define "opschain.buildService.volume_mount" -}}
- name: opschain-build-service-cert
  readOnly: true
  mountPath: /build-service-certs
{{- end -}}

{{/*
Build service certificates volume
*/}}
{{- define "opschain.buildService.volume" -}}
- name: opschain-build-service-cert
  secret:
    secretName: opschain-build-service-cert
{{- end -}}
