{{/*
Licence volume mounts
*/}}
{{- define "opschain.licence.volume_mounts" -}}
- name: opschain-licence
  mountPath: /opschain.lic
  subPath: opschain.lic
{{- end -}}

{{/*
Licence volume
*/}}
{{- define "opschain.licence.volume" -}}
- name: opschain-licence
  secret:
    secretName: opschain-licence
    items:
      - key: opschain.lic
        path: opschain.lic
        mode: 0o444
{{- end -}}
