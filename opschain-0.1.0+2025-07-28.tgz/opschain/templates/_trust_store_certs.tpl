{{/*
OpenBao certificates volume mount
*/}}
{{- define "opschain.trustStore.volume_mount" -}}
- name: opschain-trust-store
  readOnly: true
  mountPath: /etc/pki/ca-trust/source/anchors/
{{- end -}}

{{/*
OpenBao certificates volume
*/}}
{{- define "opschain.trustStore.volume" -}}
- name: opschain-trust-store
  configMap:
    name: opschain-trust-store
{{- end -}}
