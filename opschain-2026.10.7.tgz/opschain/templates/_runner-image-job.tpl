{{/*
Shared pod spec for the runner image copy Job - rendered as an ordinary resource on install
and as an upgrade/rollback hook.
*/}}
{{- define "opschain.runnerImageJob.podSpec" -}}
automountServiceAccountToken: false
restartPolicy: OnFailure
securityContext:
  runAsUser: 10001
  runAsGroup: 10001
  runAsNonRoot: true
  supplementalGroups: [10002]
  fsGroup: 10001
{{- if eq .Values.env.OPSCHAIN_VERSION "edge" }}
imagePullSecrets:
  - name: {{ include "opschain.imagePullSecretName" . }}
{{- end }}
containers:
  - args:
      - {{ .Values.imageRegistry.copyCommandOverride | default "exec rake opschain:copy_runner_image" }}
    env:
      {{- include "opschain.clusterEnv" . | nindent 6 }}
      - name: OPSCHAIN_DOCKER_USER
        value: {{ .Values.env.OPSCHAIN_DOCKER_USER | quote }}
      - name: OPSCHAIN_DOCKER_PASSWORD
        value: {{ .Values.env.OPSCHAIN_DOCKER_PASSWORD | quote }}
      - name: OPSCHAIN_VERSION
        value: {{ .Values.env.OPSCHAIN_VERSION | quote }}
      - name: OPSCHAIN_RUNNER_IMAGE
        value: {{ include "opschain.runnerImageName" . | quote }}
      {{- with .Values.env.OPSCHAIN_IMAGES_TO_COPY_TO_INTERNAL_REGISTRY }}
      - name: OPSCHAIN_IMAGES_TO_COPY_TO_INTERNAL_REGISTRY
        value: {{ . | quote }}
      {{- end }}
      {{- with .Values.imageCopyJob.env }}
      {{- toYaml . | nindent 6 }}
      {{- end }}
    envFrom:
      - configMapRef:
          name: opschain-config
    image: {{ include "opschain.apiWorkerImage" . }}
    imagePullPolicy: {{ if eq .Values.env.OPSCHAIN_VERSION "edge" }}Always{{ else }}IfNotPresent{{ end }}
    name: rake
    securityContext:
      allowPrivilegeEscalation: false
{{- with .Values.nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end -}}
