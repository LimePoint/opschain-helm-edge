{{/*
OpenBao certificates volume mount
*/}}
{{- define "opschain.secretVault.volumeMount" -}}
- name: opschain-secret-vault-cert
  readOnly: true
  mountPath: /secret-vault-certs
{{- end -}}

{{/*
OpenBao certificates volume
*/}}
{{- define "opschain.secretVault.volume" -}}
- name: opschain-secret-vault-cert
  secret:
    secretName: {{ .Values.secretVault.internalCertificateSecretName | default "opschain-secret-vault-cert" }}
{{- end -}}
